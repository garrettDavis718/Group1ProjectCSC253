﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static World.WorldDelegates;

namespace World
{
    //Item Class used for creating item objects and storing them in our item list, will be used in future iterations
    public class Item
    {
        ShowUserMessage message1 = Write;
        ShowUserMessage message2 = WriteLine;

        //constructors
        public int ID { get; set; }
        public double Weight { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int LocationID { get; set; }


        //Item Custom constructor
        public Item()
        {
            Name = "Default";
        }
        public Item(int id, string name, string description)
        {
            ID = id;
            Name = name;
            Description = description;
        }
        public Item(int id, string name, double weight, string description)
        {
            ID = id;
            Weight = weight;
            Name = name;
            Description = description;
        }
        //Overload for Items that need a location
        public Item(int id, string name, double weight, string description, int locationID)
        {
            ID = id;
            Weight = weight;
            Name = name;
            Description = description;
            LocationID = locationID;
        }
        public static void DropItem(string droppedItem, PlayerCharacter user)
        {
            Room room = Map.GetLocation(user);
            for (int i = 0; i < user.Inventory.Count; i++)
            {
                if (user.Inventory[i].Name.ToLower().Equals(droppedItem.ToLower()))
                {
                    Arrays.Map[user.XLocation, user.YLocation].Inventory.Add(user.Inventory[i]);
                    Lists.currentPlayer[0].Inventory.RemoveAt(i);
                    Console.WriteLine("Dropped " + droppedItem + " in " + room.Name);
                }
                else
                {
                    Console.WriteLine("No item by this name");
                }
            }
        }
        public static void TakeItem(Item item, PlayerCharacter user)
        {
            if (user.Weight < 50)
            {
                Lists.currentPlayer[0].Inventory.Add(item);
            }
            else
            {
                WriteLine("You are too heavy to pick this item up.");
            }
            
        }
        public static string ExamineItem(string itemName)
        {
            string output = "";
            foreach (Item item in Lists.currentPlayer[0].Inventory)
            {
                if (item.Name.ToLower().Equals(itemName.ToLower()))
                {
                    output = item.Description;
                }
            }
            return output;
        }
        
        





    }
}
