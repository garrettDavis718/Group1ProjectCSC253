﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace World
{
    public static class Arrays
    {
        public static Room[,] Map = new Room[20,20];
    }
    
}

