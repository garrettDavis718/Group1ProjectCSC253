﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static World.WorldDelegates;

namespace World
{
    public class Combat
    {
        ShowUserMessage message1 = Write;
        ShowUserMessage message2 = WriteLine;

        public static Random rand = new Random();
        public static string attack(Character attacker, Character defender)
        {
            string output = "";
            int toHit = rand.Next(0, 21);
            if (toHit > defender.ArmorClass)
            {
                int damage = attacker.Weapon.Damage;
                defender.HealthPoints -= damage;
                output = (attacker.Name + " attacks " + defender.Name + " with their " + attacker.Weapon.Name + " for " + attacker.Weapon.Damage + " " + attacker.Weapon.DmgType
                    + " Damage.");
                if (defender.HealthPoints < 0)
                {
                    output += ("\n" + attacker.Name + " has killed " + defender.Name);
                    for (int i = 0; i < Lists.CurrentEnemies.Count; i++)
                    {
                        if (defender.Name.Equals(Lists.CurrentEnemies[i].Name))
                        {
                            Lists.CurrentEnemies.RemoveAt(i);
                        }
                    }
                }
                return output;
            }
            else
            {
                output += (attacker.Name + " misses");
                return output;
            }
        }
    }
}
