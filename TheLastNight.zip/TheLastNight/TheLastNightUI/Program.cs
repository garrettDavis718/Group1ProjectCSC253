﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using World;

namespace TheLastNightUI
{
    static class Program
    {
        /*Garrett Davis, Zach, Mateo
         *11/20/21
         *This is the last iteration to be turned in for the dungeon crawl, I will be continuing to update it over time though
         *This iteration utilizes a windows form and allows almost all of the features available in console. You can currently make
         *it all the way to the end of the map if you can find and use the correct keys without dying to the enemies. 
         */
        [STAThread]
        static void Main()
        {
            DatabaseControls.LoadKeyItems();
            DatabaseControls.LoadDoors();
            DatabaseControls.LoadRooms();
            DatabaseControls.LoadPotions();
            DatabaseControls.LoadWeapons();
            DatabaseControls.LoadMobs();
            DatabaseControls.LoadItems();
            DatabaseControls.LoadTreasures();
            Map.BuildMap(Lists.rooms);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginForm());
        }
    }
}
