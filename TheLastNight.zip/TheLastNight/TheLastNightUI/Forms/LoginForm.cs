﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using World;
using static World.WorldDelegates;

namespace TheLastNightUI
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            string username = usernameBox.Text;
            string password = passwordBox.Text;
            bool loaded = false;
            loaded = DatabaseControls.LoadPlayer(username, password);
            if (loaded.Equals(true))
            {
                GameForm Form = new GameForm();
                this.Hide();
                Form.ShowDialog();  
            }
            else 
            {
                warningLbl.Visible = true;
            }
            
            
        }

        private void NewPlayerBtn_Click(object sender, EventArgs e)
        {
            NewPlayerForm form = new NewPlayerForm();
            this.Hide();
            form.ShowDialog();
            
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
