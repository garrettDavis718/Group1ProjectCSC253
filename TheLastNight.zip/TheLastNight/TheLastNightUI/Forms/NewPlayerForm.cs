﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using World;

namespace TheLastNightUI
{
    public partial class NewPlayerForm : Form
    {
        public NewPlayerForm()
        {
            InitializeComponent();
        }

        private void createPlayerBtn_Click(object sender, EventArgs e)
        {
            bool nameCheck;
            bool nameValid;
            bool passValid;
            Weapon weapon = new Weapon();
            List<Item> inventory = new List<Item>();
            int healthPoints = 0;
            int armorClass = 0;
            int xLocation = 0;
            int yLocation = 0;
            string username = usernameBox.Text;
            string password = passwordBox.Text;
            string race = "";
            string playerClass;
            nameCheck = DatabaseControls.CheckForPlayer(username);
            nameValid = Validation.ValidateName(username);
            passValid = Validation.TestPassword(password);
            if (!nameCheck.Equals(false) || !nameValid.Equals(true))
            {
                usernameWarningLbl.Visible = true;
            }
            else if (!passValid.Equals(true))
            {
                passWarningLbl.Visible = true;
            }
            else
            {
                race = raceBox.Text;
                playerClass = ClassBox.Text;
                if (race.Equals("") || playerClass.Equals(""))
                {
                    usernameWarningLbl.Visible = false;
                    passWarningLbl.Visible = false;
                    raceWarningLbl.Visible = true;
                }
                else
                {
                    switch (playerClass)
                    {
                        case "Berzerker":
                            weapon = Lists.Weapons[1];
                            healthPoints = 65;
                            armorClass = 18;
                            break;
                        case "Gunslinger":
                            weapon = Lists.Weapons[0];
                            healthPoints = 55;
                            armorClass = 15;
                            break;
                        case "Scrapper":
                            weapon = Lists.Weapons[5];
                            healthPoints = 60;
                            armorClass = 17;
                            break;
                        case "Engineer":
                            weapon = Lists.Weapons[2];
                            healthPoints = 60;
                            armorClass = 17;
                            break;
                        default:
                            playerClass = "";
                            break;
                    }
                    PlayerCharacter user = new PlayerCharacter(username, password, race, playerClass, healthPoints,
                        armorClass, xLocation, yLocation, weapon, inventory);
                    DatabaseControls.CreateNewPlayer(user);
                    Lists.currentPlayer.Add(user);
                    GameForm gameForm = new GameForm();
                    this.Hide();
                    gameForm.ShowDialog();

                }
                }
            



        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm form = new LoginForm();
            form.ShowDialog();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
