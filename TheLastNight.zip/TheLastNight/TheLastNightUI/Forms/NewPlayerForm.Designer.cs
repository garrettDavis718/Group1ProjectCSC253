﻿
namespace TheLastNightUI
{
    partial class NewPlayerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.usernameLbl = new System.Windows.Forms.Label();
            this.passwordLbl = new System.Windows.Forms.Label();
            this.usernameWarningLbl = new System.Windows.Forms.Label();
            this.usernameBox = new System.Windows.Forms.TextBox();
            this.passwordBox = new System.Windows.Forms.TextBox();
            this.createPlayerBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.backBtn = new System.Windows.Forms.Button();
            this.raceBox = new System.Windows.Forms.ComboBox();
            this.ClassBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.passWarningLbl = new System.Windows.Forms.Label();
            this.raceWarningLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(80, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "New Player";
            // 
            // usernameLbl
            // 
            this.usernameLbl.AutoSize = true;
            this.usernameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernameLbl.Location = new System.Drawing.Point(22, 99);
            this.usernameLbl.Name = "usernameLbl";
            this.usernameLbl.Size = new System.Drawing.Size(91, 20);
            this.usernameLbl.TabIndex = 1;
            this.usernameLbl.Text = "Username: ";
            // 
            // passwordLbl
            // 
            this.passwordLbl.AutoSize = true;
            this.passwordLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordLbl.Location = new System.Drawing.Point(22, 146);
            this.passwordLbl.Name = "passwordLbl";
            this.passwordLbl.Size = new System.Drawing.Size(86, 20);
            this.passwordLbl.TabIndex = 2;
            this.passwordLbl.Text = "Password: ";
            // 
            // usernameWarningLbl
            // 
            this.usernameWarningLbl.AutoSize = true;
            this.usernameWarningLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernameWarningLbl.ForeColor = System.Drawing.Color.Red;
            this.usernameWarningLbl.Location = new System.Drawing.Point(42, 32);
            this.usernameWarningLbl.Name = "usernameWarningLbl";
            this.usernameWarningLbl.Size = new System.Drawing.Size(174, 13);
            this.usernameWarningLbl.TabIndex = 3;
            this.usernameWarningLbl.Text = "Username either incorrect or in use.";
            this.usernameWarningLbl.Visible = false;
            // 
            // usernameBox
            // 
            this.usernameBox.Location = new System.Drawing.Point(135, 99);
            this.usernameBox.Name = "usernameBox";
            this.usernameBox.Size = new System.Drawing.Size(100, 20);
            this.usernameBox.TabIndex = 4;
            // 
            // passwordBox
            // 
            this.passwordBox.Location = new System.Drawing.Point(135, 145);
            this.passwordBox.Name = "passwordBox";
            this.passwordBox.Size = new System.Drawing.Size(100, 20);
            this.passwordBox.TabIndex = 5;
            // 
            // createPlayerBtn
            // 
            this.createPlayerBtn.Location = new System.Drawing.Point(86, 299);
            this.createPlayerBtn.Name = "createPlayerBtn";
            this.createPlayerBtn.Size = new System.Drawing.Size(90, 46);
            this.createPlayerBtn.TabIndex = 6;
            this.createPlayerBtn.Text = "Create New Player";
            this.createPlayerBtn.UseVisualStyleBackColor = true;
            this.createPlayerBtn.Click += new System.EventHandler(this.createPlayerBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(99, 429);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(61, 24);
            this.exitBtn.TabIndex = 7;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // backBtn
            // 
            this.backBtn.Location = new System.Drawing.Point(99, 375);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(61, 24);
            this.backBtn.TabIndex = 8;
            this.backBtn.Text = "Back";
            this.backBtn.UseVisualStyleBackColor = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // raceBox
            // 
            this.raceBox.FormattingEnabled = true;
            this.raceBox.Items.AddRange(new object[] {
            "Human",
            "Mutant",
            "Alien",
            "Robot"});
            this.raceBox.Location = new System.Drawing.Point(135, 191);
            this.raceBox.Name = "raceBox";
            this.raceBox.Size = new System.Drawing.Size(100, 21);
            this.raceBox.TabIndex = 9;
            // 
            // ClassBox
            // 
            this.ClassBox.FormattingEnabled = true;
            this.ClassBox.Items.AddRange(new object[] {
            "Berzerker",
            "Gunslinger",
            "Scrapper",
            "Engineer"});
            this.ClassBox.Location = new System.Drawing.Point(135, 238);
            this.ClassBox.Name = "ClassBox";
            this.ClassBox.Size = new System.Drawing.Size(100, 21);
            this.ClassBox.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(52, 192);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "Race:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(52, 239);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 20);
            this.label3.TabIndex = 12;
            this.label3.Text = "Class: ";
            // 
            // passWarningLbl
            // 
            this.passWarningLbl.AutoSize = true;
            this.passWarningLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passWarningLbl.ForeColor = System.Drawing.Color.Red;
            this.passWarningLbl.Location = new System.Drawing.Point(23, 57);
            this.passWarningLbl.Name = "passWarningLbl";
            this.passWarningLbl.Size = new System.Drawing.Size(216, 39);
            this.passWarningLbl.TabIndex = 13;
            this.passWarningLbl.Text = "Password incorrect\r\n(Please include Uppercase/lowercase letter \r\nand special char" +
    "acter)";
            this.passWarningLbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.passWarningLbl.Visible = false;
            // 
            // raceWarningLbl
            // 
            this.raceWarningLbl.AutoSize = true;
            this.raceWarningLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.raceWarningLbl.ForeColor = System.Drawing.Color.Red;
            this.raceWarningLbl.Location = new System.Drawing.Point(42, 57);
            this.raceWarningLbl.Name = "raceWarningLbl";
            this.raceWarningLbl.Size = new System.Drawing.Size(167, 13);
            this.raceWarningLbl.TabIndex = 14;
            this.raceWarningLbl.Text = "Please choose a Class and Race.";
            this.raceWarningLbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.raceWarningLbl.Visible = false;
            // 
            // NewPlayerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(262, 472);
            this.Controls.Add(this.raceWarningLbl);
            this.Controls.Add(this.passWarningLbl);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ClassBox);
            this.Controls.Add(this.raceBox);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.createPlayerBtn);
            this.Controls.Add(this.passwordBox);
            this.Controls.Add(this.usernameBox);
            this.Controls.Add(this.usernameWarningLbl);
            this.Controls.Add(this.passwordLbl);
            this.Controls.Add(this.usernameLbl);
            this.Controls.Add(this.label1);
            this.Name = "NewPlayerForm";
            this.Text = "NewPlayerForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label usernameLbl;
        private System.Windows.Forms.Label passwordLbl;
        private System.Windows.Forms.Label usernameWarningLbl;
        private System.Windows.Forms.TextBox usernameBox;
        private System.Windows.Forms.TextBox passwordBox;
        private System.Windows.Forms.Button createPlayerBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.ComboBox raceBox;
        private System.Windows.Forms.ComboBox ClassBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label passWarningLbl;
        private System.Windows.Forms.Label raceWarningLbl;
    }
}