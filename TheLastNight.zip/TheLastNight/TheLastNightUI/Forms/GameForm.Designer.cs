﻿
namespace TheLastNightUI
{
    partial class GameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLbl = new System.Windows.Forms.Label();
            this.hpLbl = new System.Windows.Forms.Label();
            this.northBtn = new System.Windows.Forms.Button();
            this.southBtn = new System.Windows.Forms.Button();
            this.eastBtn = new System.Windows.Forms.Button();
            this.westBtn = new System.Windows.Forms.Button();
            this.attackBtn = new System.Windows.Forms.Button();
            this.enemiesDropBox = new System.Windows.Forms.ComboBox();
            this.takeItemsDropBox = new System.Windows.Forms.ComboBox();
            this.takeBtn = new System.Windows.Forms.Button();
            this.useItemsDropBox = new System.Windows.Forms.ComboBox();
            this.useBtn = new System.Windows.Forms.Button();
            this.dropItemDropBox = new System.Windows.Forms.ComboBox();
            this.dropBtn = new System.Windows.Forms.Button();
            this.inventory = new System.Windows.Forms.ListBox();
            this.titleLbl = new System.Windows.Forms.Label();
            this.outputBox = new System.Windows.Forms.RichTextBox();
            this.weaponLbl = new System.Windows.Forms.Label();
            this.lookBtn = new System.Windows.Forms.Button();
            this.doorBox = new System.Windows.Forms.ComboBox();
            this.doorBtn = new System.Windows.Forms.Button();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.mapBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Font = new System.Drawing.Font("MS Gothic", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLbl.Location = new System.Drawing.Point(133, 108);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(48, 18);
            this.nameLbl.TabIndex = 1;
            this.nameLbl.Text = "Name";
            // 
            // hpLbl
            // 
            this.hpLbl.AutoSize = true;
            this.hpLbl.Font = new System.Drawing.Font("MS Gothic", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hpLbl.Location = new System.Drawing.Point(344, 108);
            this.hpLbl.Name = "hpLbl";
            this.hpLbl.Size = new System.Drawing.Size(28, 18);
            this.hpLbl.TabIndex = 2;
            this.hpLbl.Text = "HP";
            // 
            // northBtn
            // 
            this.northBtn.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.northBtn.Location = new System.Drawing.Point(270, 551);
            this.northBtn.Name = "northBtn";
            this.northBtn.Size = new System.Drawing.Size(75, 23);
            this.northBtn.TabIndex = 3;
            this.northBtn.Text = "Move North";
            this.northBtn.UseVisualStyleBackColor = false;
            this.northBtn.Click += new System.EventHandler(this.northBtn_Click);
            // 
            // southBtn
            // 
            this.southBtn.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.southBtn.Location = new System.Drawing.Point(270, 610);
            this.southBtn.Name = "southBtn";
            this.southBtn.Size = new System.Drawing.Size(75, 23);
            this.southBtn.TabIndex = 4;
            this.southBtn.Text = "Move South";
            this.southBtn.UseVisualStyleBackColor = false;
            this.southBtn.Click += new System.EventHandler(this.southBtn_Click);
            // 
            // eastBtn
            // 
            this.eastBtn.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.eastBtn.Location = new System.Drawing.Point(308, 581);
            this.eastBtn.Name = "eastBtn";
            this.eastBtn.Size = new System.Drawing.Size(75, 23);
            this.eastBtn.TabIndex = 5;
            this.eastBtn.Text = "Move East";
            this.eastBtn.UseVisualStyleBackColor = false;
            this.eastBtn.Click += new System.EventHandler(this.eastBtn_Click);
            // 
            // westBtn
            // 
            this.westBtn.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.westBtn.Location = new System.Drawing.Point(236, 581);
            this.westBtn.Name = "westBtn";
            this.westBtn.Size = new System.Drawing.Size(75, 23);
            this.westBtn.TabIndex = 6;
            this.westBtn.Text = "Move West";
            this.westBtn.UseVisualStyleBackColor = false;
            this.westBtn.Click += new System.EventHandler(this.westBtn_Click);
            // 
            // attackBtn
            // 
            this.attackBtn.BackColor = System.Drawing.SystemColors.Control;
            this.attackBtn.Location = new System.Drawing.Point(423, 531);
            this.attackBtn.Name = "attackBtn";
            this.attackBtn.Size = new System.Drawing.Size(75, 23);
            this.attackBtn.TabIndex = 7;
            this.attackBtn.Text = "Attack";
            this.attackBtn.UseVisualStyleBackColor = false;
            this.attackBtn.Click += new System.EventHandler(this.attackBtn_Click);
            // 
            // enemiesDropBox
            // 
            this.enemiesDropBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.enemiesDropBox.FormattingEnabled = true;
            this.enemiesDropBox.Location = new System.Drawing.Point(508, 531);
            this.enemiesDropBox.Name = "enemiesDropBox";
            this.enemiesDropBox.Size = new System.Drawing.Size(121, 21);
            this.enemiesDropBox.TabIndex = 8;
            // 
            // takeItemsDropBox
            // 
            this.takeItemsDropBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.takeItemsDropBox.FormattingEnabled = true;
            this.takeItemsDropBox.Location = new System.Drawing.Point(508, 560);
            this.takeItemsDropBox.Name = "takeItemsDropBox";
            this.takeItemsDropBox.Size = new System.Drawing.Size(121, 21);
            this.takeItemsDropBox.TabIndex = 10;
            // 
            // takeBtn
            // 
            this.takeBtn.BackColor = System.Drawing.SystemColors.Control;
            this.takeBtn.Location = new System.Drawing.Point(423, 560);
            this.takeBtn.Name = "takeBtn";
            this.takeBtn.Size = new System.Drawing.Size(75, 23);
            this.takeBtn.TabIndex = 9;
            this.takeBtn.Text = "Take";
            this.takeBtn.UseVisualStyleBackColor = false;
            this.takeBtn.Click += new System.EventHandler(this.takeBtn_Click);
            // 
            // useItemsDropBox
            // 
            this.useItemsDropBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.useItemsDropBox.FormattingEnabled = true;
            this.useItemsDropBox.Location = new System.Drawing.Point(508, 589);
            this.useItemsDropBox.Name = "useItemsDropBox";
            this.useItemsDropBox.Size = new System.Drawing.Size(121, 21);
            this.useItemsDropBox.TabIndex = 12;
            // 
            // useBtn
            // 
            this.useBtn.BackColor = System.Drawing.SystemColors.Control;
            this.useBtn.Location = new System.Drawing.Point(423, 589);
            this.useBtn.Name = "useBtn";
            this.useBtn.Size = new System.Drawing.Size(75, 23);
            this.useBtn.TabIndex = 11;
            this.useBtn.Text = "Unlock";
            this.useBtn.UseVisualStyleBackColor = false;
            this.useBtn.Click += new System.EventHandler(this.useBtn_Click);
            // 
            // dropItemDropBox
            // 
            this.dropItemDropBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dropItemDropBox.FormattingEnabled = true;
            this.dropItemDropBox.Location = new System.Drawing.Point(508, 648);
            this.dropItemDropBox.Name = "dropItemDropBox";
            this.dropItemDropBox.Size = new System.Drawing.Size(121, 21);
            this.dropItemDropBox.TabIndex = 14;
            // 
            // dropBtn
            // 
            this.dropBtn.BackColor = System.Drawing.SystemColors.Control;
            this.dropBtn.Location = new System.Drawing.Point(423, 647);
            this.dropBtn.Name = "dropBtn";
            this.dropBtn.Size = new System.Drawing.Size(75, 23);
            this.dropBtn.TabIndex = 13;
            this.dropBtn.Text = "Drop";
            this.dropBtn.UseVisualStyleBackColor = false;
            this.dropBtn.Click += new System.EventHandler(this.dropBtn_Click);
            // 
            // inventory
            // 
            this.inventory.BackColor = System.Drawing.SystemColors.Info;
            this.inventory.FormattingEnabled = true;
            this.inventory.Location = new System.Drawing.Point(12, 538);
            this.inventory.Name = "inventory";
            this.inventory.Size = new System.Drawing.Size(166, 108);
            this.inventory.TabIndex = 15;
            // 
            // titleLbl
            // 
            this.titleLbl.AutoSize = true;
            this.titleLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLbl.ForeColor = System.Drawing.Color.Chartreuse;
            this.titleLbl.Location = new System.Drawing.Point(212, 43);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(238, 39);
            this.titleLbl.TabIndex = 16;
            this.titleLbl.Text = "The Last Night";
            // 
            // outputBox
            // 
            this.outputBox.BackColor = System.Drawing.SystemColors.InfoText;
            this.outputBox.Font = new System.Drawing.Font("MS PGothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputBox.ForeColor = System.Drawing.SystemColors.Info;
            this.outputBox.Location = new System.Drawing.Point(12, 129);
            this.outputBox.Name = "outputBox";
            this.outputBox.ReadOnly = true;
            this.outputBox.Size = new System.Drawing.Size(617, 385);
            this.outputBox.TabIndex = 1;
            this.outputBox.Text = "";
            // 
            // weaponLbl
            // 
            this.weaponLbl.AutoSize = true;
            this.weaponLbl.Font = new System.Drawing.Font("MS Gothic", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponLbl.Location = new System.Drawing.Point(463, 108);
            this.weaponLbl.Name = "weaponLbl";
            this.weaponLbl.Size = new System.Drawing.Size(68, 18);
            this.weaponLbl.TabIndex = 19;
            this.weaponLbl.Text = "Weapon";
            // 
            // lookBtn
            // 
            this.lookBtn.Location = new System.Drawing.Point(194, 610);
            this.lookBtn.Name = "lookBtn";
            this.lookBtn.Size = new System.Drawing.Size(60, 23);
            this.lookBtn.TabIndex = 20;
            this.lookBtn.Text = "Look";
            this.lookBtn.UseVisualStyleBackColor = true;
            this.lookBtn.Click += new System.EventHandler(this.lookBtn_Click);
            // 
            // doorBox
            // 
            this.doorBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.doorBox.FormattingEnabled = true;
            this.doorBox.Location = new System.Drawing.Point(508, 618);
            this.doorBox.Name = "doorBox";
            this.doorBox.Size = new System.Drawing.Size(121, 21);
            this.doorBox.TabIndex = 21;
            this.doorBox.Visible = false;
            // 
            // doorBtn
            // 
            this.doorBtn.BackColor = System.Drawing.SystemColors.Control;
            this.doorBtn.Location = new System.Drawing.Point(423, 618);
            this.doorBtn.Name = "doorBtn";
            this.doorBtn.Size = new System.Drawing.Size(75, 23);
            this.doorBtn.TabIndex = 22;
            this.doorBtn.Text = "Select Door";
            this.doorBtn.UseVisualStyleBackColor = false;
            this.doorBtn.Visible = false;
            this.doorBtn.Click += new System.EventHandler(this.doorBtn_Click);
            // 
            // ExitBtn
            // 
            this.ExitBtn.Location = new System.Drawing.Point(270, 743);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(75, 23);
            this.ExitBtn.TabIndex = 23;
            this.ExitBtn.Text = "Exit";
            this.ExitBtn.UseVisualStyleBackColor = true;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // mapBtn
            // 
            this.mapBtn.Location = new System.Drawing.Point(67, 743);
            this.mapBtn.Name = "mapBtn";
            this.mapBtn.Size = new System.Drawing.Size(75, 23);
            this.mapBtn.TabIndex = 24;
            this.mapBtn.Text = "Map";
            this.mapBtn.UseVisualStyleBackColor = true;
            this.mapBtn.Click += new System.EventHandler(this.mapBtn_Click);
            // 
            // GameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(662, 778);
            this.Controls.Add(this.mapBtn);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.doorBtn);
            this.Controls.Add(this.doorBox);
            this.Controls.Add(this.lookBtn);
            this.Controls.Add(this.weaponLbl);
            this.Controls.Add(this.outputBox);
            this.Controls.Add(this.titleLbl);
            this.Controls.Add(this.inventory);
            this.Controls.Add(this.dropItemDropBox);
            this.Controls.Add(this.dropBtn);
            this.Controls.Add(this.useItemsDropBox);
            this.Controls.Add(this.useBtn);
            this.Controls.Add(this.takeItemsDropBox);
            this.Controls.Add(this.takeBtn);
            this.Controls.Add(this.enemiesDropBox);
            this.Controls.Add(this.attackBtn);
            this.Controls.Add(this.westBtn);
            this.Controls.Add(this.eastBtn);
            this.Controls.Add(this.southBtn);
            this.Controls.Add(this.northBtn);
            this.Controls.Add(this.hpLbl);
            this.Controls.Add(this.nameLbl);
            this.Name = "GameForm";
            this.Text = "GameBox";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label hpLbl;
        private System.Windows.Forms.Button northBtn;
        private System.Windows.Forms.Button southBtn;
        private System.Windows.Forms.Button eastBtn;
        private System.Windows.Forms.Button westBtn;
        private System.Windows.Forms.Button attackBtn;
        private System.Windows.Forms.ComboBox enemiesDropBox;
        private System.Windows.Forms.ComboBox takeItemsDropBox;
        private System.Windows.Forms.Button takeBtn;
        private System.Windows.Forms.ComboBox useItemsDropBox;
        private System.Windows.Forms.Button useBtn;
        private System.Windows.Forms.ComboBox dropItemDropBox;
        private System.Windows.Forms.Button dropBtn;
        private System.Windows.Forms.ListBox inventory;
        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.RichTextBox outputBox;
        private System.Windows.Forms.Label weaponLbl;
        private System.Windows.Forms.Button lookBtn;
        private System.Windows.Forms.ComboBox doorBox;
        private System.Windows.Forms.Button doorBtn;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Button mapBtn;
    }
}