﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using World;
using MapUI;

namespace TheLastNightUI
{
    public partial class GameForm : Form
    {
        public GameForm()
        {
            PlayerCharacter user = Lists.currentPlayer[0];
            InitializeComponent(); 
            InitRichTextBox();
            nameLbl.Text = user.Name;
            SetHP();
            weaponLbl.Text = user.Weapon.Name;
            loadInventory();
            loadEnemiesIntoEnemiesBox();
            loadInventoryIntoUseBox();
            loadRoomItemsIntoBox();
            loadInventoryIntoDropBox();
            Output("Welcome " + user.Name + ", to The Last Night!");
            Output("You are currently in " + Arrays.Map[user.XLocation, user.YLocation].Name);
            Output("What would you like to do? ");

        }
        public void SetHP()
        {
            hpLbl.Text = Lists.currentPlayer[0].HealthPoints.ToString() + " HP";
        }
        public void Output(string output)
        {
            outputBox.AppendText("\n" + output);
        }
        public void loadInventory()
        {
            inventory.Items.Clear();
            foreach (Item item in Lists.currentPlayer[0].Inventory)
            {
                inventory.Items.Add(item.Name);
            }
        }
        public void loadEnemiesIntoEnemiesBox()
        {
            Mob.GetCurrentEnemies();
            enemiesDropBox.Items.Clear();
            foreach (Mob npc in Lists.CurrentEnemies)
            {
                enemiesDropBox.Items.Add(npc.Name);
            }
        }
        public void loadRoomItemsIntoBox()
        {
            takeItemsDropBox.Items.Clear();
            foreach (Item item in Arrays.Map[Lists.currentPlayer[0].XLocation, Lists.currentPlayer[0].YLocation].Inventory)
            {
                if (!item.Name.Equals("Default"))
                {
                    takeItemsDropBox.Items.Add(item.Name);
                }
            }
        }
        public void loadDoorsToDoorBox()
        {
            foreach (Door door in Map.GetLocation(Lists.currentPlayer[0]).Doors)
            {
                if (!door.Name.Equals("Default"))
                    doorBox.Items.Add(door.Name);
            }

        }
        public void loadInventoryIntoUseBox()
        {
            useItemsDropBox.Items.Clear();
            PlayerCharacter user = Lists.currentPlayer[0];
            foreach (Item item in user.Inventory)
            {
                useItemsDropBox.Items.Add(item.Name);
            }
        }
        public void loadInventoryIntoDropBox()
        {
            dropItemDropBox.Items.Clear();
            PlayerCharacter user = Lists.currentPlayer[0];
            foreach (Item item in user.Inventory)
            {
                dropItemDropBox.Items.Add(item.Name);
            }
            
        }
        private void northBtn_Click(object sender, EventArgs e)
        {
            Output(Map.MoveCharacter(Lists.currentPlayer[0], "n"));
            loadEnemiesIntoEnemiesBox();
            loadRoomItemsIntoBox();
        }

        private void southBtn_Click(object sender, EventArgs e)
        {
            Output(Map.MoveCharacter(Lists.currentPlayer[0], "s"));
            loadEnemiesIntoEnemiesBox();
            loadRoomItemsIntoBox();
        }

        private void westBtn_Click(object sender, EventArgs e)
        {
            Output(Map.MoveCharacter(Lists.currentPlayer[0], "w"));
            loadEnemiesIntoEnemiesBox();
            loadRoomItemsIntoBox();
        }

        private void eastBtn_Click(object sender, EventArgs e)
        {
            Output(Map.MoveCharacter(Lists.currentPlayer[0], "e"));
            loadEnemiesIntoEnemiesBox();
            loadRoomItemsIntoBox();
        }

        private void attackBtn_Click(object sender, EventArgs e)
        {
            string enemy = enemiesDropBox.Text;
            if (enemy.Equals(""))
            {
                Output("Please choose an enemy to attack.");
            }
            else
            {
                if (Lists.CurrentEnemies.Count > 0)
                {
                    for (int i = 0; i < Lists.CurrentEnemies.Count; i++)
                    {
                        if (enemy.Equals(Lists.CurrentEnemies[i].Name))
                        {
                            Output(Combat.attack(Lists.currentPlayer[0], Lists.CurrentEnemies[i]));
                        }
                        if (Lists.CurrentEnemies.Count > 0 && Lists.CurrentEnemies[i].HealthPoints > 0)
                        {
                            Output(Combat.attack(Lists.CurrentEnemies[i], Lists.currentPlayer[0]));
                            SetHP();
                        }
                    }
                }
            }
        }

        private void takeBtn_Click(object sender, EventArgs e)
        {
            string _takenItem = takeItemsDropBox.Text;
            Item takenItem = new Item();
            int count = 0;
            PlayerCharacter user = Lists.currentPlayer[0];
            foreach (Item item in Arrays.Map[user.XLocation, user.YLocation].Inventory)
            {
                if (_takenItem.Equals(item.Name))
                {
                    takenItem = item;
                    Item.TakeItem(item, user);
                    Output("You've picked up " + item.Name);
                    loadInventory();
                    loadInventoryIntoUseBox();
                    loadInventoryIntoDropBox();
                    loadRoomItemsIntoBox();
                    
                }
                if (takenItem.Name.Equals("Default"))
                {
                    Output("No object by that name in this room");
                }
               
            }
            for (int i = 0; i < Arrays.Map[user.XLocation, user.YLocation].Inventory.Count; i++)
            {
                if (count < 1 && Arrays.Map[user.XLocation, user.YLocation].Inventory[i].Name.Equals(_takenItem))
                {
                    Arrays.Map[user.XLocation, user.YLocation].Inventory.RemoveAt(i);
                    count++;
                }
            }
        }

        private void useBtn_Click(object sender, EventArgs e)
        {
            PlayerCharacter user = Lists.currentPlayer[0];
            string keyChoice = useItemsDropBox.Text;
            Item key = new Item();
            foreach (Item item in user.Inventory)
            {
                if (keyChoice.Equals(item.Name))
                {
                    Output("Please choose a door");
                    if (Map.GetLocation(user).Doors.Count > 0 && !Map.GetLocation(user).Doors[0].Name.Equals("Default"))
                    {
                        doorBox.Visible = true;
                        doorBtn.Visible = true;
                        loadDoorsToDoorBox();
                    }
                    else
                    {
                        Output("No Door to unlock.");
                    }
                }
            }
        }
        
        //Keeps textbox focus on new line
        void InitRichTextBox()
        {
            //Init rtbTest...

            outputBox.HideSelection = false;//Hide selection so that AppendText will auto scroll to the end
        }

        private void dropBtn_Click(object sender, EventArgs e)
        {
            string dropChoice = dropItemDropBox.Text;
            Item droppedItem = new Item();
            for (int i = 0; i < Lists.currentPlayer[0].Inventory.Count; i++)
            {
                if (dropChoice.Equals(Lists.currentPlayer[0].Inventory[i].Name))
                {
                    droppedItem = Lists.currentPlayer[i].Inventory[i];
                    Output(Lists.currentPlayer[0].Inventory[i].Name + " Dropped");
                    Lists.currentPlayer[0].Inventory.RemoveAt(i);
                    Map.GetLocation(Lists.currentPlayer[0]).Inventory.Add(droppedItem);
                    loadInventory();
                    loadInventoryIntoUseBox();
                    loadInventoryIntoDropBox();
                }
            }
        }

        private void doorBtn_Click(object sender, EventArgs e)
        {
            string doorChoice = doorBox.Text;
            string keyChoice = useItemsDropBox.Text;
            KeyItem key = new KeyItem();
            foreach (KeyItem item in Lists.currentPlayer[0].Inventory)
            {
                if (keyChoice.Equals(item.Name))
                {
                    key = item;
                }
            }
            for (int i = 0; i < Map.GetLocation(Lists.currentPlayer[0]).Doors.Count; i++)
            {
                if (doorChoice.Equals(Map.GetLocation(Lists.currentPlayer[0]).Doors[i].Name) && Map.GetLocation(Lists.currentPlayer[0]).Doors[i].IsLocked.Equals("true"))
                {
                    Output(Door.UnlockDoor(Map.GetLocation(Lists.currentPlayer[0]).Doors[i], key, Lists.currentPlayer[0]));
                    doorBox.Items.Clear();
                    doorBtn.Visible = false;
                    doorBox.Visible = false;
                }
            }
            if (doorChoice.Equals(""))
            {
                Output("Please choose a door.");
            }
        }


        private void lookBtn_Click(object sender, EventArgs e)
        {
            PlayerCharacter user = Lists.currentPlayer[0];
            Mob.GetCurrentEnemies();
            Room currentLocation = Map.GetLocation(user);
            if (Lists.CurrentEnemies.Count > 0)
            {
                Output("Enemies");
                Output("--------");
                foreach (Mob npc in Lists.CurrentEnemies)
                {
                    Output(npc.Name);
                    Output(npc.Description);
                }
            }
            if (currentLocation.Inventory.Count > 0)
            {
                foreach (Item item in currentLocation.Inventory)
                {
                    if (!item.Name.Equals("Default"))
                    {
                        Output("You can see a " + item.Name);
                        Output("This is " + item.Description);
                    }
                }
            }
            if (currentLocation.Doors.Count > 0)
            {
                foreach (Door door in currentLocation.Doors)
                {
                    if (!door.Name.Equals("Default"))
                    {
                        Output("You can see a " + door.Name);
                        Output("This is " + door.Desc);
                    }
                }
            }
            Output(currentLocation.Description);
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mapBtn_Click(object sender, EventArgs e)
        {
            MainWindow map = new MainWindow();
            map.Show();

        }
    }
}
