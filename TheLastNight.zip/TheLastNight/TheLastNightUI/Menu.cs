﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using World;
using static World.WorldDelegates;

namespace TheLastNightUI
{
    public class Menu
    {
        ShowUserMessage message1 = Write;
        ShowUserMessage message2 = WriteLine;

        //GreetUser Menu for greeting every user, will create new player and will load already created players
        public static void GreetUser()
        {
            string choice;
            bool loaded;
            bool choiceCheck;
            PlayerCharacter user = new PlayerCharacter();
            WriteLine("------------Welcome to The Last Survivors!------------");
            WriteLine("Is this your first time playing? ");
            choice = Console.ReadLine();
            choice.ToLower();
            do
            {
                switch (choice)
                {
                    case "no":
                        do
                        {
                            choiceCheck = true;
                            WriteLine("Whats your name?");
                            string name = Console.ReadLine();
                            WriteLine("What's your password? ");
                            string password = Console.ReadLine();
                            loaded = DatabaseControls.LoadPlayer(name, password);
                        } while (loaded == false);
                        WriteLine(Lists.currentPlayer[0].Name + " loaded.");
                        break;
                    case "yes":
                        choiceCheck = true;
                        //CreateNewPlayer.CreateCharacter();
                        break;
                    default:
                        choiceCheck = false;
                        WriteLine("Please enter yes or no.");
                        choice = Console.ReadLine();
                        break;
                }
            } while (choiceCheck == false);
        }
        //General Game menu for character's decision, This has been rewritten to be a little cleaner
        //Everytime we do something besides exit the game, we load our current enemies list, which is 
        //a list of enemies that are at the same x and y location of our player. 
        public static void GameMenu()
        {
            bool keepGoing = true;
            PlayerCharacter user = Lists.currentPlayer[0];
            Mob.GetCurrentEnemies();
            WriteLine("Welcome " + user.Name + "!");
            WriteLine("You are currently in " + Arrays.Map[user.XLocation, user.YLocation].Name);
            WriteLine("The " + Arrays.Map[user.XLocation, user.YLocation].Name + " is " + Arrays.Map[user.XLocation, user.YLocation].Description);
            do
            {
                Mob.GetCurrentEnemies();
                WriteLine("What would you like to do? ");
                WriteLine("---------------------");
                string decision = Console.ReadLine().ToLower();
                switch (decision)
                {
                    //This will let us use move x as a move input
                    case string a when a.Contains("move"):
                        string direction;
                        if (decision.Contains(' '))
                        {
                            string[] twoWordDecision = decision.Split(' ');
                            direction = twoWordDecision[1];
                            string output = Map.MoveCharacter(user, direction);
                            WriteLine(output);
                        }
                        else
                        {
                            WriteLine("Which way would you like to move? ");
                            WriteLine("---------------------");
                            direction = Console.ReadLine();
                            string output = Map.MoveCharacter(user, direction);
                            WriteLine(output);
                        }
                        keepGoing = true;
                        break;
                    case string a when a.Contains("attack"):
                        int counter = 0;
                        Console.WriteLine("Who would you like to attack? ");
                        foreach (Mob npc in Lists.CurrentEnemies)
                        {
                            Console.WriteLine(npc.Name);
                        }
                        string enemy = Console.ReadLine().ToLower();
                        foreach (Mob npc in Lists.CurrentEnemies)
                        {
                            if (npc.Name.ToLower().Equals(enemy))
                            {
                                string keepFighting = "yes";
                                while (npc.HealthPoints > 0 && !keepFighting.Equals("no"))
                                {
                                    //npc.HealthPoints = Combat.attack(Lists.currentPlayer[0], npc);
                                    if (npc.HealthPoints > 0)
                                    {
                                       // Lists.currentPlayer[0].HealthPoints = Combat.attack(npc, Lists.currentPlayer[0]);
                                        WriteLine("Would you like to keep fighting? yes/no");
                                        keepFighting = Console.ReadLine();
                                    }
                                } 
                                counter++;
                            }
                        }
                        if (counter == 0)
                        {
                            WriteLine("No enemy exists.");
                        }
                        break;
                    case "look":
                        //Look around and display the current room's description
                        //ALso will create a list of current enemies for the user to see, 
                        //Right now the max amount of enemies they will see is one,
                        //That's just because of the limited enemy locations. 
                        WriteLine(Arrays.Map[user.XLocation, user.YLocation].Name);
                        WriteLine(Arrays.Map[user.XLocation, user.YLocation].Description);
                        foreach (Mob npc in Lists.CurrentEnemies)
                        {
                            WriteLine("Enemies: ");
                            WriteLine(npc.Name);
                        }
                        break;
                        //used for looking at a specific object in your room.
                    case string a when a.Contains("look at"):
                        string itemDescription = "";
                        string[] choices = decision.Split(' ');
                        if (choices.Length > 2)
                        {
                            string interest = choices[2];
                            if (choices.Length > 3)
                            {
                                interest += ' ';
                                interest += choices[3];
                                WriteLine(interest);
                            }

                            foreach (Character character in Lists.CurrentEnemies)
                            {
                                if (character.Name.ToLower().Equals(interest.ToLower()))
                                {
                                    itemDescription = "You see a " + character.Name + " with " + character.HealthPoints + "health points.";
                                    itemDescription += "\nThe " + character.Name + " is holding a " + character.Weapon.Name;
                                }

                            }
                            foreach (Item item in Arrays.Map[user.XLocation, user.YLocation].Inventory)
                            {
                                if (item.Name.ToLower().Equals(interest.ToLower()))
                                {
                                    itemDescription = (item.Description);
                                }
                            }
                            foreach (Door door in Arrays.Map[user.XLocation, user.YLocation].Doors)
                            {
                                if (door.Name.ToLower().Equals(interest.ToLower()))
                                {
                                    itemDescription = (door.Desc);
                                }
                            }
                            if (itemDescription.Equals(""))
                            {
                                WriteLine("Theres nothing like that to look at in this room.");
                            }
                            else
                            {
                                WriteLine(itemDescription);
                            }
                        }
                        else
                        {
                            WriteLine("Please type an object when using the *Look at* command.");
                        }
                        break;
                    case "take":
                    case "grab":
                        Item takenItem = new Item(0, "Default", "Default");
                        int count = 0;
                        WriteLine("What would you like to pickup?");
                        string input = Console.ReadLine().ToLower();
                        foreach (Item item in Arrays.Map[user.XLocation, user.YLocation].Inventory)
                        {
                            if (input.Equals(item.Name.ToLower()))
                            {
                                takenItem = item;
                                Item.TakeItem(item, user);
                                WriteLine("You've picked up " + item.Name);
                            }
                            if (takenItem.Name.Equals("Default"))
                            {
                                WriteLine("No object by that name in this room");
                                break;
                            }
                        }
                        for (int i = 0; i < Arrays.Map[user.XLocation, user.YLocation].Inventory.Count; i++)
                        {  
                            if (count < 1 && Arrays.Map[user.XLocation, user.YLocation].Inventory[i].Equals(takenItem))
                            {
                                Arrays.Map[user.XLocation, user.YLocation].Inventory.RemoveAt(i);
                                count++;
                            }
                        }
                        break;
                        //All 3 of these cases do the same thing
                    case string a when a.Contains("take ") ||  a.Contains("grab "): 
                        if (a.Contains(' '))
                        {
                            Item _takenItem = new Item(0, "Default", "Default");
                            int _count = 0;
                            string[] twoWordDecision = a.Split(' ');
                            string takenObject = twoWordDecision[1];
                            if (twoWordDecision.Count() > 2)
                            {
                                takenObject += " " + twoWordDecision[2];
                            }
                                foreach (Item item in Arrays.Map[user.XLocation, user.YLocation].Inventory)
                                {
                                    if (takenObject.ToLower().Equals(item.Name.ToLower()))
                                    {
                                        _takenItem = item;
                                        Item.TakeItem(item, user);
                                        WriteLine("You've picked up " + item.Name);
                                    }                                   
                                }
                            if (_takenItem.Name.Equals("Default"))
                            {
                                WriteLine("No object by that name in this room");
                                break;
                            }
                            for (int i = 0; i < Arrays.Map[user.XLocation, user.YLocation].Inventory.Count; i++)
                                {
                                    if (_count < 1 && Arrays.Map[user.XLocation, user.YLocation].Inventory[i].Equals(_takenItem))
                                    {
                                        Arrays.Map[user.XLocation, user.YLocation].Inventory.RemoveAt(i);
                                        _count++;
                                        break;
                                    }
                                }
                        }
                        break;

                    case "drop":
                        WriteLine("   Inventory   ");
                        WriteLine("----------------");
                        foreach (Item item in user.Inventory)
                        {
                            WriteLine(item.Name);
                        }
                        string droppedItem = Console.ReadLine();
                        Item.DropItem(droppedItem, user);
                        break;
                    case "examine":
                        WriteLine("What would you like to examine? ");
                        WriteLine("   Inventory   ");
                        WriteLine("----------------");
                        foreach (Item item in user.Inventory)
                        {
                            WriteLine(item.Name);
                        }
                        string examinedItem = Console.ReadLine();
                        string examination = Item.ExamineItem(examinedItem);
                        if (!examination.Equals(""))
                        {
                            WriteLine(examination);
                        }
                        else
                        {
                            WriteLine("No item like that in your inventory.");
                        }
                        break;
                    case "use":
                        WriteLine("What would you like to use? ");
                        foreach (Item item in user.Inventory)
                        {
                            WriteLine(item.Name); 
                        }
                        string usedItem = Console.ReadLine();
                        string doorChoice = "";
                        KeyItem keyChoice = new KeyItem();
                        foreach (Item item in user.Inventory)
                        {
                            if (usedItem.ToLower().Equals(item.Name.ToLower()))
                            {
                                keyChoice = KeyItem.GetKeyItem(usedItem);
                                WriteLine("What would you like to use the " + item.Name + " on? " );
                                doorChoice = Console.ReadLine();
                            }
                        }
                        foreach (Door door in Arrays.Map[user.XLocation, user.YLocation].Doors)
                        {
                            if (doorChoice.ToLower().Equals(door.Name.ToLower()))
                            {
                                Door.UnlockDoor(door, keyChoice, user);
                            }
                        }
                        break;
                    case "exit":
                        keepGoing = false;
                        break;
                    default:
                        keepGoing = true;
                        break;
                }
                //Die option, ends the current game
                if (user.HealthPoints < 0)
                {
                    WriteLine("You have died.");
                    keepGoing = false;
                }
                else
                {
                    WriteLine("You are currently in " + Arrays.Map[user.XLocation, user.YLocation].Name);
                }
            } while (keepGoing == true);
            //thank user for playing. 
            WriteLine("Thanks for playing!");
            Console.ReadLine();

        }
    }
}

